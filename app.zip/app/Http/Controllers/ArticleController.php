<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Article;

class ArticleController extends Controller
{
    public function index()
    {
        $articles = DB::table('articles')->paginate(5);

        return view('articles.index', ['articles' => $articles]);
    }
    public function create()
    {
        return view('articles.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' =>'mimes:jpg,png,gif,jpeg|max:5120'
        ]); 
        $imageData = $request->all();
        if ($image = $request->file('image')) {
            $destinationPath = 'image/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $imageData['image'] = $profileImage;
       
        }     
//print_r($imageData);die;
        Article::create($imageData);

        return redirect()->route('articles')
        ->with('success','Article created successfully.');
    }
    public function show()
    {
        $articles = DB::table('articles')->paginate(5);
        return view('articles.show',compact('articles'));
    }
    public function edit(Article $article)
    {
        return view('articles.edit',compact('article'));
    }
    public function update(Request $request, Article $article)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            
            'image' =>'mimes:jpg,png,gif,jpeg|max:5120'
        ]);
        $imageData = $request->all();
        if ($image = $request->file('image')) {
            $destinationPath = 'image/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $imageData['image'] = $profileImage;
       
        }  

        $article->update($imageData);
  
        return redirect()->route('articles')
                        ->with('success','Article updated successfully');
    }
    public function destroy(Article $article)
    {
        $article->delete();
  
        return redirect()->route('articles')
                        ->with('success','Article deleted successfully');
    }

}
